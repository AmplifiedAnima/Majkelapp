

from django.contrib import admin



from . models import Trainingvalue, Word, profile


admin.site.register(Word)
admin.site.register(Trainingvalue)
admin.site.register(profile)

