
from tkinter import W
from django.contrib.auth.models import User
from django.db import models

class profile(models.Model):
    user= models.OneToOneField(User,null=True,on_delete=models.CASCADE)
    name= models.CharField(max_length=100, null=True)
    waga= models.PositiveIntegerField(default=0, blank=True, null=True)
    wzrost = models.PositiveIntegerField(default=0, blank=True, null=True)
    updated = models.DateTimeField(auto_now=True)
    created= models.DateTimeField(auto_now_add=True)

    def __str__(self):
        
        return self.name

    def __str__(self):
        return self.waga

    def __str__(self):
        return self.name



class Meta:
    ordering = ['-updated,-created']

class Trainingvalue(models.Model):


    UPPERBIEXERCISE_PULLUPS ="PULLUPS"
    UPPERBIEXERCISE_CHINUPS ="CHINUPS"
    UPPERBIEXERCISE_OVERHEADPRESS= "OVERHEADPRESS"
    UPPERBIEXERCISE_BARBELLROWS="BARBELLROWS"
    UPPERBIEXERCISE_TRXROWS="TRXROWS"
    UPPERBIEXERCISE_CHOICES=[
        (UPPERBIEXERCISE_PULLUPS, "PULLUPS"),
        (UPPERBIEXERCISE_CHINUPS,"CHINUPS"),
        (UPPERBIEXERCISE_OVERHEADPRESS, "OVERHEADPRESS"),
        (UPPERBIEXERCISE_BARBELLROWS, "BARBELLROWS"),
        (UPPERBIEXERCISE_TRXROWS,"TRXROWS"),
    ]

    UPPERUNIEXERCISE_BENTPRESS = "BENTPRESS"
    UPPERUNIEXERCISE_WINDMILL = "WINDMILL"
    UPPERUNIEXERCISE_ROWS="ROWS"
    UPPERUNIEXERCISE_CHOICES=[
        (UPPERUNIEXERCISE_BENTPRESS, "BENTPRESS"),
        (UPPERUNIEXERCISE_WINDMILL,"WINDMILL"),
        (UPPERUNIEXERCISE_ROWS,"ROWS"),
        ]

    LOWERBIEXERCISE_GLUTEBRIDGE="GLUTEBRIDGE"
    LOWERBIEXERCISE_SWING="SWING"
    LOWERBIEXERCISE_CHOICES=[
        (LOWERBIEXERCISE_GLUTEBRIDGE,"GLUTEBRIDGE"),
        (LOWERBIEXERCISE_SWING,"SWING"),
        ]

    LOWERUNIEXERCISE_LUNGES ="LUNGES"
    LOWERUNIEXERCISE_STEPUPS = "STEPUPS"
    LOWERUNIEXERCISE_BULGARIANSPLITSQUATS= "BULGARIANSPLITSQUATS"
    LOWERUNIEXERCISE_CHOICES=[
        (LOWERUNIEXERCISE_LUNGES, "LUNGES"),
        (LOWERUNIEXERCISE_STEPUPS,"STEPUPS"),
        (LOWERUNIEXERCISE_BULGARIANSPLITSQUATS,"BULGARIANSPLITSQUATS"),
        ]

    COREEXERCISE_RUSSIANTWIST="RUSSIANTWIST"
    COREEXERCISE_PLANK="PLANK"
    COREEXERCISE_REVERSEPLANK="REVERSEPLANK"
    COREEXERCISE_SIDEPLANK="SIDEPLANK"
    COREEXERCISE_CHOICES=[
        (COREEXERCISE_RUSSIANTWIST,"RUSSIANTWIST"),
        (COREEXERCISE_PLANK,"PLANK"),
        (COREEXERCISE_REVERSEPLANK,"REVERSEPLANK"),
        (COREEXERCISE_SIDEPLANK,"SIDEPLANK")
        ]

    WHOLEBODYEXERCISE_SLEDPUSH= "SLEDPUSH"
    WHOLEBODYEXERCISE_SLEDPULL="SLEDPULL"
    WHOLEBODYEXERCISE_TURKISHGETUP="TURKISHGETUP"
    WHOLEBODYEXERCISE_CHOICES=[
        (WHOLEBODYEXERCISE_SLEDPUSH, "SLEDPUSH"),
        (WHOLEBODYEXERCISE_SLEDPUSH, "SLEDPULL"),
        (WHOLEBODYEXERCISE_SLEDPUSH, "TURKISHGETUP"),
    ]
  

    
    MESOCYCLE_GPP= "GPP"
    MESOCYCLE_ACC= "ACC"
    MESOCYCLE_PEAK= "PEAK"
    MESOCYCLE_CASUALTRAINING= "CASUALTRAINING"
    MESOCYCLE_CHOICES=[
        (MESOCYCLE_GPP, "GPP"),
        (MESOCYCLE_ACC, "ACC"),
        (MESOCYCLE_PEAK, "PEAK"),
        (MESOCYCLE_CASUALTRAINING, "CASUALTRAINING")
    ]
    




    upperbodbi= models.CharField(max_length=20, choices=UPPERBIEXERCISE_CHOICES,default=UPPERBIEXERCISE_PULLUPS)
    upperboduni = models.CharField(max_length=20, choices=UPPERUNIEXERCISE_CHOICES,default=UPPERUNIEXERCISE_ROWS)
    
    lowerbodybi= models.CharField(max_length=20, choices=LOWERBIEXERCISE_CHOICES,default=LOWERBIEXERCISE_SWING)
    lowerbodyuni= models.CharField(max_length=20, choices=LOWERUNIEXERCISE_CHOICES,default=LOWERUNIEXERCISE_BULGARIANSPLITSQUATS)

    coretraining=  models.CharField(max_length=20, choices=COREEXERCISE_CHOICES,default=COREEXERCISE_RUSSIANTWIST)
    
    wholebodyexercise =  models.CharField(max_length=20, choices=WHOLEBODYEXERCISE_CHOICES,default=WHOLEBODYEXERCISE_TURKISHGETUP)
    

    user= models.ForeignKey(User,null=True, on_delete=models.CASCADE)

    
    SQUAT1RM= models.PositiveIntegerField(default=0, blank=True, null=True)
    DEADLIFT1RM=models.PositiveIntegerField(default=0, blank=True, null=True)
    BENCHPRESS1RM= models.PositiveIntegerField(default=0, blank=True, null=True)
    
    #ATHLETIC
    mesocycle= models.CharField(max_length=20, choices=MESOCYCLE_CHOICES,default=MESOCYCLE_GPP)
    updated = models.DateTimeField(auto_now=True)
    created= models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return self.user


    def __str__(self):
        
        return str(self.SQUAT1RM),str(self.DEADLIFT1RM),str(self.BENCHPRESS1RM)


    def __innit__(self):
        return self.mesocycle

 
   
class Word(models.Model):
    
    english = models.CharField( max_length=100)
    polish = models.CharField( max_length=100)
    genre = models.CharField( max_length=30)
    description = models.TextField(null=True,blank=True)
    updated = models.DateTimeField(auto_now=True)
    created= models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.id}:{self.english} - {self.polish}"

  

